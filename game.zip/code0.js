gdjs.Game_32SceneCode = {};
gdjs.Game_32SceneCode.localVariables = [];
gdjs.Game_32SceneCode.idToCallbackMap = new Map();
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95951Objects1= [];
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95951Objects2= [];
gdjs.Game_32SceneCode.GDAlternative_9595Small_9595CastleObjects1= [];
gdjs.Game_32SceneCode.GDAlternative_9595Small_9595CastleObjects2= [];
gdjs.Game_32SceneCode.GDAlternative_9595towerObjects1= [];
gdjs.Game_32SceneCode.GDAlternative_9595towerObjects2= [];
gdjs.Game_32SceneCode.GDAlternative_9595Small_9595towerObjects1= [];
gdjs.Game_32SceneCode.GDAlternative_9595Small_9595towerObjects2= [];
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95952Objects1= [];
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95952Objects2= [];
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95953Objects1= [];
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95953Objects2= [];
gdjs.Game_32SceneCode.GDGreen_9595house_95951Objects1= [];
gdjs.Game_32SceneCode.GDGreen_9595house_95951Objects2= [];
gdjs.Game_32SceneCode.GDGreen_9595house_9595small_95951Objects1= [];
gdjs.Game_32SceneCode.GDGreen_9595house_9595small_95951Objects2= [];
gdjs.Game_32SceneCode.GDGreen_9595house_95952Objects1= [];
gdjs.Game_32SceneCode.GDGreen_9595house_95952Objects2= [];
gdjs.Game_32SceneCode.GDGreen_9595house_9595small_95952Objects1= [];
gdjs.Game_32SceneCode.GDGreen_9595house_9595small_95952Objects2= [];
gdjs.Game_32SceneCode.GDMayan_9595PyramidObjects1= [];
gdjs.Game_32SceneCode.GDMayan_9595PyramidObjects2= [];
gdjs.Game_32SceneCode.GDRed_9595house_95951Objects1= [];
gdjs.Game_32SceneCode.GDRed_9595house_95951Objects2= [];
gdjs.Game_32SceneCode.GDRed_9595house_95952Objects1= [];
gdjs.Game_32SceneCode.GDRed_9595house_95952Objects2= [];
gdjs.Game_32SceneCode.GDRed_9595house_9595small_95951Objects1= [];
gdjs.Game_32SceneCode.GDRed_9595house_9595small_95951Objects2= [];
gdjs.Game_32SceneCode.GDRed_9595house_9595small_95952Objects1= [];
gdjs.Game_32SceneCode.GDRed_9595house_9595small_95952Objects2= [];
gdjs.Game_32SceneCode.GDSmall_9595CastleObjects1= [];
gdjs.Game_32SceneCode.GDSmall_9595CastleObjects2= [];
gdjs.Game_32SceneCode.GDSmall_9595towerObjects1= [];
gdjs.Game_32SceneCode.GDSmall_9595towerObjects2= [];
gdjs.Game_32SceneCode.GDTowerObjects1= [];
gdjs.Game_32SceneCode.GDTowerObjects2= [];
gdjs.Game_32SceneCode.GDpyramidObjects1= [];
gdjs.Game_32SceneCode.GDpyramidObjects2= [];
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95952Objects1= [];
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95952Objects2= [];
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95954Objects1= [];
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95954Objects2= [];
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95951Objects1= [];
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95951Objects2= [];
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95953Objects1= [];
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95953Objects2= [];
gdjs.Game_32SceneCode.GDDead_9595treeObjects1= [];
gdjs.Game_32SceneCode.GDDead_9595treeObjects2= [];
gdjs.Game_32SceneCode.GDFrozen_9595long_9595treeObjects1= [];
gdjs.Game_32SceneCode.GDFrozen_9595long_9595treeObjects2= [];
gdjs.Game_32SceneCode.GDFrozen_9595treeObjects1= [];
gdjs.Game_32SceneCode.GDFrozen_9595treeObjects2= [];
gdjs.Game_32SceneCode.GDFrozen_9595pine_9595treeObjects1= [];
gdjs.Game_32SceneCode.GDFrozen_9595pine_9595treeObjects2= [];
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95952Objects1= [];
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95952Objects2= [];
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95951Objects1= [];
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95951Objects2= [];
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95953Objects1= [];
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95953Objects2= [];
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95954Objects1= [];
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95954Objects2= [];
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95956Objects1= [];
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95956Objects2= [];
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95955Objects1= [];
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95955Objects2= [];
gdjs.Game_32SceneCode.GDLong_9595orange_9595treeObjects1= [];
gdjs.Game_32SceneCode.GDLong_9595orange_9595treeObjects2= [];
gdjs.Game_32SceneCode.GDLong_9595snow_9595treeObjects1= [];
gdjs.Game_32SceneCode.GDLong_9595snow_9595treeObjects2= [];
gdjs.Game_32SceneCode.GDLong_9595treeObjects1= [];
gdjs.Game_32SceneCode.GDLong_9595treeObjects2= [];
gdjs.Game_32SceneCode.GDOrange_9595Bush_95951Objects1= [];
gdjs.Game_32SceneCode.GDOrange_9595Bush_95951Objects2= [];
gdjs.Game_32SceneCode.GDOrange_9595Bush_95952Objects1= [];
gdjs.Game_32SceneCode.GDOrange_9595Bush_95952Objects2= [];
gdjs.Game_32SceneCode.GDOrange_9595Bush_95953Objects1= [];
gdjs.Game_32SceneCode.GDOrange_9595Bush_95953Objects2= [];
gdjs.Game_32SceneCode.GDOrange_9595pine_9595treeObjects1= [];
gdjs.Game_32SceneCode.GDOrange_9595pine_9595treeObjects2= [];
gdjs.Game_32SceneCode.GDOrange_9595Bush_95954Objects1= [];
gdjs.Game_32SceneCode.GDOrange_9595Bush_95954Objects2= [];
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95951Objects1= [];
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95951Objects2= [];
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95952Objects1= [];
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95952Objects2= [];
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95953Objects1= [];
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95953Objects2= [];
gdjs.Game_32SceneCode.GDPalm_9595treeObjects1= [];
gdjs.Game_32SceneCode.GDPalm_9595treeObjects2= [];
gdjs.Game_32SceneCode.GDOrange_9595treeObjects1= [];
gdjs.Game_32SceneCode.GDOrange_9595treeObjects2= [];
gdjs.Game_32SceneCode.GDPine_9595treeObjects1= [];
gdjs.Game_32SceneCode.GDPine_9595treeObjects2= [];
gdjs.Game_32SceneCode.GDSnow_9595pine_9595treeObjects1= [];
gdjs.Game_32SceneCode.GDSnow_9595pine_9595treeObjects2= [];
gdjs.Game_32SceneCode.GDSnow_9595treeObjects1= [];
gdjs.Game_32SceneCode.GDSnow_9595treeObjects2= [];
gdjs.Game_32SceneCode.GDTreeObjects1= [];
gdjs.Game_32SceneCode.GDTreeObjects2= [];
gdjs.Game_32SceneCode.GDbush_95951Objects1= [];
gdjs.Game_32SceneCode.GDbush_95951Objects2= [];
gdjs.Game_32SceneCode.GDbush_95953Objects1= [];
gdjs.Game_32SceneCode.GDbush_95953Objects2= [];
gdjs.Game_32SceneCode.GDbush_95952Objects1= [];
gdjs.Game_32SceneCode.GDbush_95952Objects2= [];
gdjs.Game_32SceneCode.GDcactus_95951Objects1= [];
gdjs.Game_32SceneCode.GDcactus_95951Objects2= [];
gdjs.Game_32SceneCode.GDbush_95954Objects1= [];
gdjs.Game_32SceneCode.GDbush_95954Objects2= [];
gdjs.Game_32SceneCode.GDcactus_95952Objects1= [];
gdjs.Game_32SceneCode.GDcactus_95952Objects2= [];
gdjs.Game_32SceneCode.GDcactus_95953Objects1= [];
gdjs.Game_32SceneCode.GDcactus_95953Objects2= [];
gdjs.Game_32SceneCode.GDFull_9595moonObjects1= [];
gdjs.Game_32SceneCode.GDFull_9595moonObjects2= [];
gdjs.Game_32SceneCode.GDSunObjects1= [];
gdjs.Game_32SceneCode.GDSunObjects2= [];
gdjs.Game_32SceneCode.GDBigCookieObjects1= [];
gdjs.Game_32SceneCode.GDBigCookieObjects2= [];
gdjs.Game_32SceneCode.GDClickTextObjects1= [];
gdjs.Game_32SceneCode.GDClickTextObjects2= [];
gdjs.Game_32SceneCode.GDCookieCountTextObjects1= [];
gdjs.Game_32SceneCode.GDCookieCountTextObjects2= [];
gdjs.Game_32SceneCode.GDCPSTextObjects1= [];
gdjs.Game_32SceneCode.GDCPSTextObjects2= [];
gdjs.Game_32SceneCode.GDCursorUpgradeButtonObjects1= [];
gdjs.Game_32SceneCode.GDCursorUpgradeButtonObjects2= [];
gdjs.Game_32SceneCode.GDCursorUpgradeLabelObjects1= [];
gdjs.Game_32SceneCode.GDCursorUpgradeLabelObjects2= [];
gdjs.Game_32SceneCode.GDAutoUpgradeButtonObjects1= [];
gdjs.Game_32SceneCode.GDAutoUpgradeButtonObjects2= [];
gdjs.Game_32SceneCode.GDAutoUpgradeLabelObjects1= [];
gdjs.Game_32SceneCode.GDAutoUpgradeLabelObjects2= [];
gdjs.Game_32SceneCode.GDLeaderboardButtonObjects1= [];
gdjs.Game_32SceneCode.GDLeaderboardButtonObjects2= [];
gdjs.Game_32SceneCode.GDLeaderboardLabelObjects1= [];
gdjs.Game_32SceneCode.GDLeaderboardLabelObjects2= [];


gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBigCookieObjects1Objects = Hashtable.newFrom({"BigCookie": gdjs.Game_32SceneCode.GDBigCookieObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDClickTextObjects1Objects = Hashtable.newFrom({"ClickText": gdjs.Game_32SceneCode.GDClickTextObjects1});
gdjs.Game_32SceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ClickText"), gdjs.Game_32SceneCode.GDClickTextObjects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "CPSTimer");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SaveTimer");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDClickTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDClickTextObjects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("CPSText"), gdjs.Game_32SceneCode.GDCPSTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("CookieCountText"), gdjs.Game_32SceneCode.GDCookieCountTextObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCookieCountTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCookieCountTextObjects1[i].getBehavior("Text").setText("Cookies: " + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber()));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCPSTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCPSTextObjects1[i].getBehavior("Text").setText("per second: " + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber()));
}
}
{/* Mismatched object type - skipped. */}
{/* Mismatched object type - skipped. */}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BigCookie"), gdjs.Game_32SceneCode.GDBigCookieObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDBigCookieObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14518692);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDBigCookieObjects1 */
gdjs.Game_32SceneCode.GDClickTextObjects1.length = 0;

{runtimeScene.getScene().getVariables().getFromIndex(7).add(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber());
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDClickTextObjects1Objects, (( gdjs.Game_32SceneCode.GDBigCookieObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDBigCookieObjects1[0].getCenterXInScene()), (( gdjs.Game_32SceneCode.GDBigCookieObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDBigCookieObjects1[0].getCenterYInScene()), "");
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Click_02.aac", false, 100, 1);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDClickTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDClickTextObjects1[i].getBehavior("Tween").addObjectPositionYTween2("rise", -60, "easeOutQuad", 0.6, false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDClickTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDClickTextObjects1[i].getBehavior("Tween").addObjectOpacityTween2("fade", 0, "easeOutQuad", 0.6, false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Mismatched object type - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() >= runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(7).sub(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(6).add(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(Math.round(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() * 1.5));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Mismatched object type - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() >= runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber());
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(7).sub(runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber());
}
{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(5).add(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(Math.round(runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() * 1.5));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "CPSTimer") > 1;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(7).add(runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber());
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "CPSTimer");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SaveTimer") > 10;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() > runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber());
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber());
}
{gdjs.evtTools.leaderboards.savePlayerScore(runtimeScene, "highscores", runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber(), "Player");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SaveTimer");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Mismatched object type - skipped. */if (isConditionTrue_0) {
{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "highscores", true);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ClickText"), gdjs.Game_32SceneCode.GDClickTextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDClickTextObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDClickTextObjects1[i].getBehavior("Tween").hasFinished("fade") ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDClickTextObjects1[k] = gdjs.Game_32SceneCode.GDClickTextObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDClickTextObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDClickTextObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDClickTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDClickTextObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


};

gdjs.Game_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32SceneCode.GDBackground_9595Mountain_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Small_9595CastleObjects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Small_9595CastleObjects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595towerObjects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595towerObjects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Small_9595towerObjects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Small_9595towerObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_9595small_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_9595small_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_9595small_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_9595small_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDMayan_9595PyramidObjects1.length = 0;
gdjs.Game_32SceneCode.GDMayan_9595PyramidObjects2.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_9595small_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_9595small_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_9595small_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_9595small_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595CastleObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595CastleObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595towerObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595towerObjects2.length = 0;
gdjs.Game_32SceneCode.GDTowerObjects1.length = 0;
gdjs.Game_32SceneCode.GDTowerObjects2.length = 0;
gdjs.Game_32SceneCode.GDpyramidObjects1.length = 0;
gdjs.Game_32SceneCode.GDpyramidObjects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDDead_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDDead_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDFrozen_9595long_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDFrozen_9595long_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDFrozen_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDFrozen_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDFrozen_9595pine_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDFrozen_9595pine_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95956Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95956Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDLong_9595orange_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDLong_9595orange_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDLong_9595snow_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDLong_9595snow_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDLong_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDLong_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595pine_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595pine_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDPalm_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDPalm_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDPine_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDPine_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDSnow_9595pine_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDSnow_9595pine_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDSnow_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDSnow_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDTreeObjects1.length = 0;
gdjs.Game_32SceneCode.GDTreeObjects2.length = 0;
gdjs.Game_32SceneCode.GDbush_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDbush_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDbush_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDbush_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDbush_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDbush_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDcactus_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDcactus_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDbush_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDbush_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDcactus_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDcactus_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDcactus_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDcactus_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDFull_9595moonObjects1.length = 0;
gdjs.Game_32SceneCode.GDFull_9595moonObjects2.length = 0;
gdjs.Game_32SceneCode.GDSunObjects1.length = 0;
gdjs.Game_32SceneCode.GDSunObjects2.length = 0;
gdjs.Game_32SceneCode.GDBigCookieObjects1.length = 0;
gdjs.Game_32SceneCode.GDBigCookieObjects2.length = 0;
gdjs.Game_32SceneCode.GDClickTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDClickTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDCookieCountTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDCookieCountTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDCPSTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDCPSTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDCursorUpgradeButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDCursorUpgradeButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDCursorUpgradeLabelObjects1.length = 0;
gdjs.Game_32SceneCode.GDCursorUpgradeLabelObjects2.length = 0;
gdjs.Game_32SceneCode.GDAutoUpgradeButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDAutoUpgradeButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDAutoUpgradeLabelObjects1.length = 0;
gdjs.Game_32SceneCode.GDAutoUpgradeLabelObjects2.length = 0;
gdjs.Game_32SceneCode.GDLeaderboardButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDLeaderboardButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDLeaderboardLabelObjects1.length = 0;
gdjs.Game_32SceneCode.GDLeaderboardLabelObjects2.length = 0;

gdjs.Game_32SceneCode.eventsList0(runtimeScene);
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Small_9595CastleObjects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Small_9595CastleObjects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595towerObjects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595towerObjects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Small_9595towerObjects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Small_9595towerObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDBackground_9595Mountain_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_9595small_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_9595small_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_9595small_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595house_9595small_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDMayan_9595PyramidObjects1.length = 0;
gdjs.Game_32SceneCode.GDMayan_9595PyramidObjects2.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_9595small_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_9595small_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_9595small_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDRed_9595house_9595small_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595CastleObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595CastleObjects2.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595towerObjects1.length = 0;
gdjs.Game_32SceneCode.GDSmall_9595towerObjects2.length = 0;
gdjs.Game_32SceneCode.GDTowerObjects1.length = 0;
gdjs.Game_32SceneCode.GDTowerObjects2.length = 0;
gdjs.Game_32SceneCode.GDpyramidObjects1.length = 0;
gdjs.Game_32SceneCode.GDpyramidObjects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDAlternative_9595Bush_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDDead_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDDead_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDFrozen_9595long_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDFrozen_9595long_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDFrozen_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDFrozen_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDFrozen_9595pine_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDFrozen_9595pine_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595Small_9595tree_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95956Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95956Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95955Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreen_9595small_9595tree_95955Objects2.length = 0;
gdjs.Game_32SceneCode.GDLong_9595orange_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDLong_9595orange_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDLong_9595snow_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDLong_9595snow_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDLong_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDLong_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595pine_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595pine_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595Bush_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595small_9595tree_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDPalm_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDPalm_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDOrange_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDPine_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDPine_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDSnow_9595pine_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDSnow_9595pine_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDSnow_9595treeObjects1.length = 0;
gdjs.Game_32SceneCode.GDSnow_9595treeObjects2.length = 0;
gdjs.Game_32SceneCode.GDTreeObjects1.length = 0;
gdjs.Game_32SceneCode.GDTreeObjects2.length = 0;
gdjs.Game_32SceneCode.GDbush_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDbush_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDbush_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDbush_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDbush_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDbush_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDcactus_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDcactus_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDbush_95954Objects1.length = 0;
gdjs.Game_32SceneCode.GDbush_95954Objects2.length = 0;
gdjs.Game_32SceneCode.GDcactus_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDcactus_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDcactus_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDcactus_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDFull_9595moonObjects1.length = 0;
gdjs.Game_32SceneCode.GDFull_9595moonObjects2.length = 0;
gdjs.Game_32SceneCode.GDSunObjects1.length = 0;
gdjs.Game_32SceneCode.GDSunObjects2.length = 0;
gdjs.Game_32SceneCode.GDBigCookieObjects1.length = 0;
gdjs.Game_32SceneCode.GDBigCookieObjects2.length = 0;
gdjs.Game_32SceneCode.GDClickTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDClickTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDCookieCountTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDCookieCountTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDCPSTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDCPSTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDCursorUpgradeButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDCursorUpgradeButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDCursorUpgradeLabelObjects1.length = 0;
gdjs.Game_32SceneCode.GDCursorUpgradeLabelObjects2.length = 0;
gdjs.Game_32SceneCode.GDAutoUpgradeButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDAutoUpgradeButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDAutoUpgradeLabelObjects1.length = 0;
gdjs.Game_32SceneCode.GDAutoUpgradeLabelObjects2.length = 0;
gdjs.Game_32SceneCode.GDLeaderboardButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDLeaderboardButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDLeaderboardLabelObjects1.length = 0;
gdjs.Game_32SceneCode.GDLeaderboardLabelObjects2.length = 0;


return;

}

gdjs['Game_32SceneCode'] = gdjs.Game_32SceneCode;
